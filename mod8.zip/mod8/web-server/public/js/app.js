console.log('Client side js file is loaded');
