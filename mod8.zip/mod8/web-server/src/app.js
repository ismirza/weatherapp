//mapping
const path = require('path')
const express = require('express')
const hbs = require('hbs')
const geocode = require('./utils/geocode')
const forecast = require('./utils/forecast')

const app = express()


//define the paths for express configs
const publicDirectoryPath = path.join(__dirname, '../public')
const viewPath = path.join(__dirname, '../templates/views')
const partialsPath = path.join(__dirname, '../templates/partials')

//setup  hbs engine and views locations
app.set('view engine', 'hbs')
app.set('views', viewsPath)
hbs.registerPartials(partialsPath)

//setup static publicDirectory
app.use(express.static(publicDirectoryPath))

app.get('', (req, res) =>{
  res.render('index', {
    title: 'Weather',
    name: 'Tomlin'
  })
})

//create support
//create  About..create route for the 404
//404
//new york times article
app.get('/nytimes', function(req, res) {
    articles.GetArticles(function(data){
        res.render('nytimes', {
            title1 : data[0],
            title2 : data[1],
            title3 : data[2],
    });

    });
});

app.use(function(req, res, next){
    res.status(404);
    res.render('404');
});
//About
app.get('/about', function(req, res) {
    res.render('about', {
        aboutme: modules.getabout(),
        skills: modules.getskills()
    });
});
//support
app.get('/support', function(req, res) {
    res.render('support', {
    });
});

//Weather route

app.listen(3000,  () => {
  console.log('server is up on port 3000 at ppu')
})
