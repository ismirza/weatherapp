// Here we are using const to go out and get geocode and forecast
//that feeds our API

const geocode  = require/'.utils/geocode')
const forecast  = require/'.utils/forecast')

//customer address
const address = process.argv[2]

if(!address) {
  console.log('add your address')
}else{
  //if wrong we are passing latitude and longitude
  geocode(address, (error, { latitude, longitude, location }) => {
    if (error) {
      return console.log(error)
    }

    forecast(latitude, longitude, (error, forecastData) => {
      if (error) {
        return console.log(error)
      }
      console.log(location)
      console.log(forecastData)

    })
  })
}
