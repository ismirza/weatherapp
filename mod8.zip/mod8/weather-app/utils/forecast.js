const request = require('request')

const forecast = (latitude, longitude, callback) => {
  const url = 'https://api.darksky.net/forecast/ca691c4818503ade10abf511b865d175/' + latitude + ',' + longitude

  request({ url, json: true}, (error, { body }) => {
    if(error) {
      callback('Not able to connect to the weather service', undefined)

    } else if (body.error) {
      callback('Not able to find the location', undefined)
    }else {
      callback(undefined, body.daily.data[0].summary + 'Rn its ' + body.currently.temperature +  ' degrees out. There is a ' + body.currently.precipProbabiligy + '% chance of rain.')
    }
  })
}

module.exports = forecast
